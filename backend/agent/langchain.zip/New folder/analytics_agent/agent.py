
import os

from sqlalchemy.orm import Session

from openai import AzureOpenAI

from app.database.models import (

    RetailerProduct,

    RestockRequest,

    Order,

    OrderItem,

    Payment
)

# ==========================================
# ANALYTICS AGENT
# ==========================================
class AnalyticsAgent:

    def __init__(self):

        self.client = AzureOpenAI(

            api_key=os.getenv(
                "AZURE_OPENAI_API_KEY"
            ),

            api_version=os.getenv(
                "AZURE_OPENAI_API_VERSION"
            ),

            azure_endpoint=os.getenv(
                "AZURE_OPENAI_ENDPOINT"
            )
        )

    # ======================================
    # ALL PRODUCTS
    # ======================================
    def get_all_products(

        self,

        retailer_id,

        db: Session
    ):

        products = (

            db.query(RetailerProduct)

            .filter(
                RetailerProduct.retailer_id
                == retailer_id
            )

            .all()
        )

        return [

            {
                "product":
                product.name,

                "stock":
                product.quantity,

                "category":
                product.category,

                "price":
                float(product.price),

                "status":
                (
                    "Critical"
                    if product.quantity < 10
                    else "Low Stock"
                    if product.quantity < 50
                    else "In Stock"
                )
            }

            for product in products
        ]

    # ======================================
    # TOTAL SALES
    # ======================================
    def get_total_sales(

        self,

        retailer_id,

        db: Session
    ):

        orders = (

            db.query(Order)

            .filter(
                Order.retailer_id
                == retailer_id
            )

            .all()
        )

        total = sum(

            float(order.total_price or 0)

            for order in orders
        )

        return round(total, 2)

    # ======================================
    # TOTAL ORDERS
    # ======================================
    def get_total_orders(

        self,

        retailer_id,

        db: Session
    ):

        return (

            db.query(Order)

            .filter(
                Order.retailer_id
                == retailer_id
            )

            .count()
        )

    # ======================================
    # LOW STOCK PRODUCTS
    # ======================================
    def get_low_stock_products(

        self,

        retailer_id,

        db: Session
    ):

        products = (

            db.query(RetailerProduct)

            .filter(
                RetailerProduct.retailer_id
                == retailer_id
            )

            .filter(
                RetailerProduct.quantity < 50
            )

            .all()
        )

        return [

            {
                "product":
                product.name,

                "stock":
                product.quantity,

                "category":
                product.category,

                "status":
                (
                    "Critical"
                    if product.quantity < 10
                    else "Low Stock"
                )
            }

            for product in products
        ]

    # ======================================
    # TOP PRODUCTS
    # ======================================
    def get_top_products(

        self,

        retailer_id,

        db: Session
    ):

        # ----------------------------------
        # GET RETAILER ORDERS
        # ----------------------------------
        orders = (

            db.query(Order)

            .filter(
                Order.retailer_id
                == retailer_id
            )

            .all()
        )

        product_sales = {}

        # ----------------------------------
        # LOOP THROUGH ORDERS
        # ----------------------------------
        for order in orders:

            # ------------------------------
            # GET ORDER ITEMS
            # ------------------------------
            items = (

                db.query(OrderItem)

                .filter(
                    OrderItem.order_id
                    == order.id
                )

                .all()
            )

            # ------------------------------
            # CALCULATE SALES
            # ------------------------------
            for item in items:

                # ==========================
                # FIXED PRODUCT ACCESS
                # ==========================

                if item.product is None:

                    continue

                product_name = item.product.name

                quantity = item.quantity

                # ==========================
                # STORE SALES
                # ==========================

                if product_name not in product_sales:

                    product_sales[
                        product_name
                    ] = 0

                product_sales[
                    product_name
                ] += quantity

        # ----------------------------------
        # SORT PRODUCTS
        # ----------------------------------
        sorted_products = sorted(

            product_sales.items(),

            key=lambda x: x[1],

            reverse=True
        )

        # ----------------------------------
        # RETURN TOP 5
        # ----------------------------------
        return [

            {
                "product": product,

                "units_sold": units
            }

            for product, units
            in sorted_products[:5]
        ]

    # ======================================
    # PENDING RESTOCKS
    # ======================================
    def get_pending_restocks(

        self,

        retailer_id,

        db: Session
    ):

        requests = (

            db.query(RestockRequest)

            .filter(
                RestockRequest.retailer_id
                == retailer_id
            )

            .filter(
                RestockRequest.status
                == "Pending"
            )

            .all()
        )

        return [

            {
                "product":
                request.product_name,

                "quantity":
                request.requested_quantity,

                "status":
                request.status
            }

            for request in requests
        ]

    # ======================================
    # PAYMENT SUMMARY
    # ======================================
    def get_payment_summary(

        self,

        retailer_id,

        db: Session
    ):

        payments = (

            db.query(Payment)

            .filter(
                Payment.retailer_id
                == retailer_id
            )

            .all()
        )

        total = sum(

            float(payment.amount or 0)

            for payment in payments
        )

        return {

            "total_revenue":
            round(total, 2),

            "completed":
            len([
                p for p in payments
                if p.status == "Completed"
            ]),

            "pending":
            len([
                p for p in payments
                if p.status == "Pending"
            ])
        }

    # ======================================
    # MAIN RUNNER
    # ======================================
    def run(

        self,

        query,

        retailer_id,

        db: Session
    ):

        analytics = {

            # --------------------------------
            # PRODUCTS
            # --------------------------------
            "all_products":
            self.get_all_products(
                retailer_id,
                db
            ),

            # --------------------------------
            # SALES
            # --------------------------------
            "total_sales":
            self.get_total_sales(
                retailer_id,
                db
            ),

            "total_orders":
            self.get_total_orders(
                retailer_id,
                db
            ),

            # --------------------------------
            # INVENTORY
            # --------------------------------
            "low_stock_products":
            self.get_low_stock_products(
                retailer_id,
                db
            ),

            # --------------------------------
            # TOP PRODUCTS
            # --------------------------------
            "top_products":
            self.get_top_products(
                retailer_id,
                db
            ),

            # --------------------------------
            # RESTOCKS
            # --------------------------------
            "pending_restocks":
            self.get_pending_restocks(
                retailer_id,
                db
            ),

            # --------------------------------
            # PAYMENTS
            # --------------------------------
            "payments":
            self.get_payment_summary(
                retailer_id,
                db
            )
        }

        # ==================================
        # AI RESPONSE
        # ==================================
        response = self.client.chat.completions.create(

            model=os.getenv(
                "AZURE_OPENAI_DEPLOYMENT_NAME"
            ),

            messages=[

                {
                    "role": "system",

                    "content": """

                    You are SmartRetailAI
                    Analytics Assistant.

                    Responsibilities:

                    - Analyze sales
                    - Analyze inventory
                    - Explain low stock
                    - Explain payments
                    - Explain business performance
                    - Give concise business insights

                    IMPORTANT:

                    - If user asks about products,
                      use all_products.

                    - If user asks about low stock,
                      use low_stock_products.

                    - If user asks about payments,
                      use payments.

                    - If user asks about sales,
                      use sales analytics.

                    - If user asks about inventory,
                      use all_products.

                    Never mention only low-stock
                    products when user asks about
                    all inventory/products.

                    """
                },

                {
                    "role": "user",

                    "content": f"""

                    QUERY:
                    {query}

                    ANALYTICS:
                    {analytics}

                    """
                }
            ]
        )

        # ==================================
        # RETURN RESPONSE
        # ==================================
        return {

            "summary":
            response.choices[0]
            .message.content,

            "analytics":
            analytics
        }
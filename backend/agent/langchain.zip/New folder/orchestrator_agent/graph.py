from langgraph.graph import StateGraph

from typing import TypedDict


class AgentState(TypedDict):

    query: str

    role: str

    user_id: int

    response: str


graph = StateGraph(AgentState)
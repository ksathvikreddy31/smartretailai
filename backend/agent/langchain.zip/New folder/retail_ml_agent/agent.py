from agent.retail_ml_agent.tools import (

    forecast_product,

    anomaly_check
)


class RetailMLAgent:

    def __init__(self):

        self.product_map = {

            "smartphone": "CE100",

            "jeans": "FA202",

            "mixer grinder": "HK400",

            "electric toothbrush": "HP303"
        }

    # ======================================
    # FIND PRODUCT
    # ======================================

    def find_product(

        self,

        query
    ):

        query = query.lower()

        for name, pid in (

            self.product_map.items()
        ):

            if name in query:

                return pid, name

        return None, None

    # ======================================
    # MAIN RUN
    # ======================================

    def run(

        self,

        query,

        retailer_id,

        db
    ):

        query_lower = query.lower()

        product_id, product_name = (

            self.find_product(query)
        )

        if product_id is None:

            return (
                "Please specify a product.\\n"
                "Example: Smartphone"
            )

        # ==================================
        # FORECAST
        # ==================================

        if any(

            word in query_lower

            for word in [

                "forecast",
                "predict",
                "future",
                "demand",
                "trend"
            ]
        ):

            forecast = forecast_product(
                product_id
            )

            if forecast is None:

                return (
                    "Forecast model unavailable."
                )

            latest = forecast.iloc[-1]

            predicted_sales = round(

                latest["yhat"],

                2
            )

            response = (

                f"📈 Forecast Result\\n\\n"

                f"Product: {product_name.title()}\\n"

                f"Predicted Sales: "

                f"{predicted_sales}\\n\\n"
            )

            if predicted_sales > 50:

                response += (

                    "Trend: High Demand\\n"

                    "Recommendation: "

                    "Restock Soon"
                )

            else:

                response += (

                    "Trend: Stable Demand"
                )

            return response

        # ==================================
        # ANOMALY
        # ==================================

        if any(

            word in query_lower

            for word in [

                "anomaly",
                "abnormal",
                "spike",
                "suspicious"
            ]
        ):

            result = anomaly_check(
                product_id
            )

            if result == -1:

                return (

                    f"⚠️ Anomaly Detected "

                    f"in {product_name.title()} sales."
                )

            return (

                f"✅ No anomaly detected "

                f"for {product_name.title()}."
            )

        return (

            "I can help with:\\n"

            "- Forecasting\\n"

            "- Demand Prediction\\n"

            "- Trend Analysis\\n"

            "- Anomaly Detection"
        )
from typing import TypedDict

class AgentState(TypedDict):

    query: str

    customer_id: int

    intent: str

    response: str
from .retriever import retrieve_company_context

from .tools import (
    get_customer_orders,
    get_payment_status,
    search_product
)

from .prompt import SYSTEM_PROMPT

from .llm import llm

# ==========================================
# ROUTER NODE
# ==========================================
def router_node(state):

    query = state["query"].lower()

    # ---------------------------
    # ORDERS
    # ---------------------------
    if any(word in query for word in [
        "my order",
        "orders",
        "track order",
        "delivery"
    ]):

        state["intent"] = "orders"

    # ---------------------------
    # PAYMENTS
    # ---------------------------
    elif any(word in query for word in [
        "payment",
        "refund",
        "transaction"
    ]):

        state["intent"] = "payments"

    # ---------------------------
    # PRODUCTS
    # ---------------------------
    elif any(word in query for word in [
        "product",
        "price",
        "stock",
        "available"
    ]):

        state["intent"] = "products"

    # ---------------------------
    # COMPANY INFO
    # ---------------------------
    else:

        state["intent"] = "rag"

    return state

# ==========================================
# RAG NODE
# ==========================================
def rag_node(state):

    context = retrieve_company_context(
        state["query"]
    )

    prompt = f"""
    {SYSTEM_PROMPT}

    COMPANY INFORMATION:
    {context}

    USER QUESTION:
    {state["query"]}

    ANSWER:
    """

    response = llm.invoke(prompt)

    state["response"] = response.content

    return state

# ==========================================
# TOOL NODE
# ==========================================
def tool_node(state):

    intent = state["intent"]

    customer_id = state["customer_id"]

    query = state["query"]

    # ---------------------------
    # ORDERS
    # ---------------------------
    if intent == "orders":

        tool_result = get_customer_orders(
            customer_id
        )

    # ---------------------------
    # PAYMENTS
    # ---------------------------
    elif intent == "payments":

        tool_result = get_payment_status(
            customer_id
        )

    # ---------------------------
    # PRODUCTS
    # ---------------------------
    elif intent == "products":

        tool_result = search_product(
            query
        )

    else:

        tool_result = "No matching tool found."

    prompt = f"""
    {SYSTEM_PROMPT}

    TOOL RESULT:
    {tool_result}

    USER QUESTION:
    {query}

    ANSWER:
    """

    response = llm.invoke(prompt)

    state["response"] = response.content

    return state
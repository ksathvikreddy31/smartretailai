from sqlalchemy.orm import Session

from app.database.db import SessionLocal

from app.database.models import (
    Order,
    Payment,
    AIProduct
)

# ==========================================
# CUSTOMER ORDERS
# ==========================================
def get_customer_orders(customer_id: int):

    db: Session = SessionLocal()

    try:

        orders = (
            db.query(Order)
            .filter(Order.user_id == customer_id)
            .all()
        )

        if not orders:
            return "No orders found."

        response = []

        for order in orders:

            response.append({
                "order_id": order.id,
                "status": order.status,
                "total_price": order.total_price
            })

        return response

    finally:
        db.close()

# ==========================================
# PAYMENT STATUS
# ==========================================
def get_payment_status(customer_id: int):

    db: Session = SessionLocal()

    try:

        payments = (
            db.query(Payment)
            .filter(Payment.user_id == customer_id)
            .all()
        )

        if not payments:
            return "No payment history found."

        response = []

        for payment in payments:

            response.append({
                "payment_id": payment.id,
                "amount": payment.amount,
                "status": payment.status,
                "method": payment.method
            })

        return response

    finally:
        db.close()

# ==========================================
# PRODUCT SEARCH
# ==========================================
def search_product(query: str):

    db: Session = SessionLocal()

    try:

        product = (
            db.query(AIProduct)
            .filter(
                AIProduct.product_name.ilike(
                    f"%{query}%"
                )
            )
            .first()
        )

        if not product:
            return "Product not found."

        return {
            "product_name": product.product_name,
            "category": product.category,
            "price": product.price,
            "stock": product.stock
        }

    finally:
        db.close()